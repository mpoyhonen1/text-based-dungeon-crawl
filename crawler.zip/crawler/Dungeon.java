package com.crawler;

public class Dungeon {
	private DungeonRoom[] rooms;

	public void init() {
		System.out.println("\t\tinit()");
		rooms = new DungeonRoom[10];

		for (int i = 0; i < 10; i++) {
			int tmp = (int) (Math.random() * 2) + 1;

			switch (tmp) {
			case 1:
				System.out.println("CHEEZ1");
				rooms[i] = new LootRoom();
				break;
			case 2:
				System.out.println("CHEEZ2");
				rooms[i] = new MonsterRoom();
				System.out.println("CHEEZ2.1");
				break;
			default:
				System.out.println("Error.");
				System.exit(0);
			}

			System.out.println(i);
		}

	}

	public DungeonRoom[] getRooms() {
		System.out.println("\t\tgetRooms()");
		return rooms;
	}

	public String toString() {
		return rooms.toString();
	}

}
