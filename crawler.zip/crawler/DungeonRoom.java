package com.crawler;

public abstract class DungeonRoom extends Dungeon {

	public abstract int getLoot();

	public abstract String getName();

	public String toString() {
		return "DungeonRoom()";
	}

}
