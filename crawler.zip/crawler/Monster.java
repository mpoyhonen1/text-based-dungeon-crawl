package com.crawler;

public abstract class Monster extends MonsterRoom {
	private final String name;
	private int health;
	Player player;

	protected Monster(String name) {
		this.name = name;
		this.health = 100;
	}

	public int getHealth() {
		return health;
	}

	public void setHealth() {
		health -= damage();
	}
	
	public boolean monsterDead() {
		if (monster.getHealth() <= 0) {
			return true;
		}
		
		return false;
	}

	public abstract int damage();

	public abstract int droppedLoot();
	
	public String toString() {
		return "\n\t\tMonsterRoom(): " + name + " " + health;
	}

}
