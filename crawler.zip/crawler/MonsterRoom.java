package com.crawler;

public class MonsterRoom extends DungeonRoom {
	Monster monster;
	Player player;

	public MonsterRoom() {
		// System.out.println("MonsterRoom()");

		int spawnMonster = (int) (Math.random() * 3) + 1;

		switch (spawnMonster) {
		case 1:
			System.out.println("\nMonsterRoom - switch - crawler");
			monster = new Crawler();
			break;
		case 2:
			System.out.println("\nMonsterRoom - switch - walker");
			monster = new Walker();
			break;
		case 3:
			System.out.println("\nMonsterRoom - switch - bigboy");
			monster = new BigBoy();
			break;
		default:
			System.out.println("Error.");
			break;
		}

	}

	@Override
	public int getLoot() {
		// return player.setLoot(player.getLoot() + loot);
		return monster.getLoot();
	}

	@Override
	public String getName() {
		return "monsterroom toString";
	}

}
