package com.crawler;

/**
 * Class that contains methods for the monster, Crawler. 
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 * Project 1
 *
 */

import java.util.*;

public class Player {
	private static final int ATTACK_MAX = 35;
	
	private ArrayList roomsExp = new ArrayList();

	private String name;
	private int totalLoot, health;
		
	public Player(String name) {
		this.name = name;
		totalLoot = 0;
		health = 100;
		roomsExp.clear();
	}
	
	public String flee() {
		String toReturn = "";

		int flee = (int) (Math.random() * 2) + 1;

		switch (flee) {
		case 1:
			toReturn = "Flee!";
			break;
		case 2:
			toReturn = "You have chosen to attack!";
			fight();
			break;
		default:
			System.out.println("Error!");
			break;
		}
		
		return toReturn;
	}

	public int getLoot() {
		return totalLoot;
	}
	
	public void setLoot(int loot) {
		totalLoot = loot;
	}

	public void setHealth(int health) {
		this.health = health;
		checkHealth();
	}

	public int getHealth() {
		return health;
	}

	public void checkHealth() {
		if (health <= 0) {
			System.exit(0);
		}
	}

	public int fight() {
//		int newHealth = Monster.getHealth() - ((int) (Math.random() * ATTACK_MAX) + 3);
//		return Monster.setHealth(newHealth);
		return 0;
	}

	public void setRoomsExp(DungeonRoom room) {
		roomsExp.add(room);
	}
	
	public int getRooms() {
		return roomsExp.size();
	}

	public String toString() {
		return "\nName: " + name + "\nHealth " + health + "\nLoot " + totalLoot + "\nRooms Explored: " + roomsExp;
	}

}
