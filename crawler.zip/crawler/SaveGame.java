package com.crawler;

public class SaveGame {
	
}
