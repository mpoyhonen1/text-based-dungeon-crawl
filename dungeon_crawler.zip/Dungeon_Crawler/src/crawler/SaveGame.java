package crawler;

public class SaveGame {
	
}
