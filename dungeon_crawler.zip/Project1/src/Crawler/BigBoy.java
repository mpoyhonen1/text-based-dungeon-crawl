package Crawler;
/**
 * Class that contains methods for the monster BigBoy
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 * Project 1
 *
 */

public class BigBoy extends Monster {

	public BigBoy(String name) {
		super("BigBoy");
	}

	private static final int ATTACK_MAX = 20;
	private static final int MAX_LOOTMONSTER = 70;
	int damage = 0;

	/**
	 * Gets the total loot the BigBoy has
	 * 
	 * @return total loot
	 */
	@Override
	public int getLoot() {
		int monsterTotalLoot= (int)(Math.random()*MAX_LOOTMONSTER)+20;
		return monsterTotalLoot;
	}
	
	/**
	 *Shows what loot BigBoy has dropped
	 *
	 * @return total loot dropped
	 */
		public int DropedLoot(){
			int dropedLoot=0;
			if (this.loot()<1){
				
				int command = (int)((Math.random()*2)+1);
				
				switch(command){
					case 1:
						dropedLoot= (int)(Math.random()*20)+10;
						break;
					case 2:
						dropedLoot=5;
						break;
				}
			}
				return dropedLoot;
			
			}
		
		/**
		 * randomizes the amount of damage occuring to BigBoy
		 * 
		 * @return amount of damage
		 */
		public int Damage(){
			this.damage = (int) (Math.random() * ATTACK_MAX)+6;
			return this.damage;
		}
	}


