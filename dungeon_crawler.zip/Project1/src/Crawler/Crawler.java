package Crawler;
/**
 * Class that contains methods for the monster, Crawler. 
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 * Project 1
 *
 */
public class Crawler extends Monster {
	
	public Crawler(String name) {
		super("Crawler");
	}

	private static final int ATTACK_MAX = 5;
	private static final int MAX_LOOTMONSTER=20;
	int damage=0;
	
	/**
	 * Gets the total loot the BigBoy has
	 * 
	 * @return total loot
	 */
	@Override
	public int getLoot() {
		int monsterTotalLoot= (int)(Math.random()*MAX_LOOTMONSTER)+5;
		return monsterTotalLoot;		
	}
	/**
	 * randomizes the amount of loot dropped
	 * 
	 * @return the dropped loot
	 */
	public int DropedLoot(){
		int dropedLoot=0;
		if (this.loot()<1){
			
			int command = (int)((Math.random()*2)+1);
			
			switch(command){
				case 1:
					dropedLoot= (int)(Math.random()*11);
					break;
				case 2:
					dropedLoot=0;
					break;
			}
		}
			return dropedLoot;
		
		}
	
	/**
	 *  randomizes the amount of damage occuring to the Crawler
	 * 
	 * @return amount of damage
	 */
	public int Damage(){
		this.damage = (int) (Math.random() * ATTACK_MAX);
		return this.damage;
	}
	
	}

