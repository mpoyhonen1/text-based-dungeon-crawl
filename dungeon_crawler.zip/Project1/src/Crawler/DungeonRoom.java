package Crawler;
import java.util.ArrayList;
/**
 * Class that contains methods for the monster, Crawler. 
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 * Project 1
 *
 */
public abstract class DungeonRoom extends Dungeon{

	private ArrayList roomList = new ArrayList();
	/**
	 * Randomizes and array list of 10 1's and 2's
	 * 
	 * Case 1 is the loot room
	 * Case 2 is the monster room
	 */
	public DungeonRoom() {
		for (int i = 0; i < 10; i++) {
			int tmp = (int)(Math.random() * 2) + 1;

			switch (tmp) {
			case 1:
				LootRoom L= new LootRoom();
				roomList.add(L);
				break;
			case 2:
				MonsterRoom M = new MonsterRoom();
				roomList.add(M);
				break;
			default:
				System.out.println("Error.");
				System.exit(0);
			}
		}
	}
	
	/**
	 * Gets the loot from room
	 * 
	 * @return loot in room
	 */
	public abstract int getLoot();
	
/**
 * Gets room from array list
 * 
 * @return room from array list
 */
	public ArrayList<String> getRoomList(){
		return this.roomList;
	}
}
