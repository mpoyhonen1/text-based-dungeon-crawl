package Crawler;

/**
 * Class that contains methods for the monster, Crawler.
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 *         Project 1
 *
 */

public class LootRoom extends DungeonRoom {
	private static final int MAX_LOOT = 10;
	private static final int 	BREAD = 10;
	private int treasure;
	

	/**
	 * Sets amount of loot found in loot room
	 */
	public LootRoom() {
		treasure = 1 + (int) (Math.random() * MAX_LOOT);
		
	}
	
	
	/**
	 * Gets the bread integer amount from object
	 * 
	 * @return bread
	 */
	public int getBread() {
		return ;
	}

	/**
	 * Gets the loot from room
	 * 
	 * @return amount of loot
	 */
	@Override
	public int getLoot() {
		return treasure;
	}

}
