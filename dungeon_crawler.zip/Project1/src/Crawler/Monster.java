package Crawler;
/**
 * Class that contains methods for the monsters.
 * Extends monster room 
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 * Project 1
 *
 */ 

public abstract class Monster extends MonsterRoom {
	
	private String name;

	public Monster(String name) {

	}

	public String flee(){
		
		String toReturn = "";
		int flee = (int) (Math.random() * 2) + 1;
		switch (flee) {
		case 1:
			toReturn = "The Monster has chosen to flee! It lives for another day~";
		case 2:
			toReturn = this.getName() +" has noticed you and chosen to attack you! ";
			this.fight();
		}
		return toReturn;
	}
	

	public int loot() {
		return this.loot();
	}

	public int DropLoot() {
		return this.DropLoot();
	}

	public int Damage() {
		return this.Damage();
	}

	public int fight() {
		return this.Damage();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

}