package Crawler;
/**
 * Class that contains methods for the monster room
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 * Project 1
 *
 */ 

public class MonsterRoom extends DungeonRoom {
	public MonsterRoom() {
		Monster monster;

		int command = (int) (Math.random() * 3) + 1;

		switch (command) {
		case 1:
			monster = new Crawler("Crawler");
			break;
		case 2:
			monster = new Walker("Walker");
			break;
		case 3:
			monster = new BigBoy("Bigboy");
			break;
		}
	}

	@Override
	public int getLoot() {
		return this.getLoot();
	}
}
