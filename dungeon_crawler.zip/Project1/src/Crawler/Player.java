package Crawler;
/**
 * Class that contains methods for the monster, Crawler. 
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 * Project 1
 *
 */

import java.util.*;

public class Player {
    private String name;
    private int totalLoot;
    private int health;
    private ArrayList roomsExp = new ArrayList();
    private static final int MAX_ATTACK=10; 
    private int scoreFinal=0;
    
    
    public Player(String name) {
        this.name = name;
        totalLoot = 0;
        health = 100;
        roomsExp.clear();
    }

    /**
     * Sets loot at 0 to start game
     * 
     * @param loot
     */
    public void setLoot(int loot) {
        this.totalLoot = loot;
    }
    
    /**
     * gets total loot amount
     * 
     * @return loot amount
     */
    public int getLoot() {
        return totalLoot;
    }
    
    /**
     * sets health at 100 at the start of the game
     * 
     * @param health
     */
    public void setHealth(int health) {
        this.health = health;
        checkHealth();
    }
    /**
     * gets health amount
     * 
     * @return health value
     */
    public int getHealth() {
        return health;
    }
    /**
     * Checks health and if health is equal or less that 0
     * 
     * @return Game Over
     */
    public void checkHealth() {
        if (health <= 0) {
            // gameOver()
            System.exit(0);
        }
    }
    /**
     * Allows player to fight monster in monster rooms
     * 
     * @return health after fight
     */
    public int fight(){
    	
    	
    	
    	
    	return health;
    }
 
    /**
     * sets the total number of explored
     * @param room
     */
    public void setRoomsExp(DungeonRoom room) {
        roomsExp.add(room);
    }
    /**
     * Final score once game is completed
     * 
     * @return final score
     */
    public int score(){
    	scoreFinal+=getLoot();
    	return scoreFinal;
    }
    /**
     * Displays name, health, total loot, and rooms explored
     */
    public String toString() {
        return "\nName: " + name + "\nHealth " + health + "\nLoot " + totalLoot + "\nRooms Explored: " + roomsExp;
    }

}
