package Crawler;
/**
 * Class that contains methods for the monster, Walker. 
 * 
 * @author Mark Poyhonen and Izabel Mohamed
 * 
 * Project 1
 *
 */ 


public class Walker extends Monster {
	private static final int ATTACK_MAX = 10;
	private static final int MAX_LOOTMONSTER=45;
	int damage=0;
	
	public Walker(String name) {
		super("Walker");
	}
	
	@Override
	public int getLoot() {
		int monsterTotalLoot= (int)(Math.random()*MAX_LOOTMONSTER)+3;
		return monsterTotalLoot;	
	}
	
	public int DropedLoot(){
		int dropedLoot=0;
		if (this.loot()<1){
			
			int command = (int)((Math.random()*2)+1);
			
			switch(command){
				case 1:
					dropedLoot= (int)(Math.random()*11)+5;
					break;
				case 2:
					dropedLoot=0;
					break;
			}
		}
			return dropedLoot;
		
		}
	
	
	public int Damage(){
		this.damage = (int) (Math.random() * ATTACK_MAX)+3;
		return this.damage;
	}
	

}
